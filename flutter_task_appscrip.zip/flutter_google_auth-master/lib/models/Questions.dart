class Question {
  final int id, answer;
  final String question;
  final List<String> options;

  Question({this.id, this.question,  this.options, this.answer});
}

const List sample_data = [

  {
    "id": 1,
    "category":"General Knowledge",
    "type":"multiple",
    "difficulty":"easy",
    "question":"Virgin Trains, Virgin Atlantic and Virgin Racing, are all companies owned by which famous entrepreneur? ",
    "correct_answer":"Richard Branson",
    "incorrect_answers":["Alan Sugar","Donald Trump","Bill Gates","Richard Branson"],
    "answer_index": 3
  },

  {
    "id": 2,
    "category":"General Knowledge",
    "type":"multiple",
    "difficulty":"easy",
    "question":"What word represents the letter &#039;T&#039; in the NATO phonetic alphabet?",
    "correct_answer":"Tango",
    "incorrect_answers":["Target","Taxi","Turkey","Tango"],
    "answer_index": 3
  },

  {
    "id": 3,
    "category":"General Knowledge",
    "type":"multiple",
    "difficulty":"easy",
    "question":"Which one of the following rhythm games was made by Harmonix?",
    "correct_answer":"Rock Band",
    "incorrect_answers":["Meat Beat Mania","Guitar Hero Live","Dance Dance Revolution","Rock Band"],
    "answer_index": 3
  },

  {
    "id": 4,
    "category":"General Knowledge",
    "type":"multiple",
    "difficulty":"easy",
    "question":"Who is depicted on the US hundred dollar bill?",
    "correct_answer":"Benjamin Franklin",
    "incorrect_answers":["George Washington","Abraham Lincoln","Thomas Jefferson","Benjamin Franklin"],
    "answer_index": 3
  },

  {
    "id": 5,
    "category":"General Knowledge",
    "type":"multiple",
    "difficulty":"easy",
    "question":"What is the name of Poland in Polish?",
    "correct_answer":"Polska",
    "incorrect_answers":["Pupcia","Polszka","P&oacute;land","Polska"],
    "answer_index": 3
  },

  {
    "id": 6,
    "category":"General Knowledge",
    "type":"multiple",
    "difficulty":"easy",
    "question":"The New York Times slogan is, &ldquo;All the News That&rsquo;s Fit to&hellip;&rdquo;",
    "correct_answer":"Print",
    "incorrect_answers":["Digest","Look","Read","Print"],
    "answer_index": 3
  },

  {
    "id": 6,
    "category":"General Knowledge",
    "type":"multiple",
    "difficulty":"easy",
    "question":"What company developed the vocaloid Hatsune Miku?",
    "correct_answer":"Crypton Future Media",
    "incorrect_answers":["Sega","Sony","Yamaha Corporation","Crypton Future Media"],
    "answer_index": 3
  },

  {
    "id": 7,
    "category":"General Knowledge",
    "type":"multiple",
    "difficulty":"easy",
    "question":"What nuts are used in the production of marzipan?",
    "correct_answer":"Almonds",
    "incorrect_answers":["Peanuts","Walnuts","Pistachios","Almonds"],
    "answer_index": 3
  },

  {
    "id": 7,
    "category":"General Knowledge",
    "type":"multiple",
    "difficulty":"easy",
    "question":"How many furlongs are there in a mile?",
    "correct_answer":"Eight",
    "incorrect_answers":["Two","Four","Six","Eight"],
    "answer_index": 3
  },

  {
    "id": 7,
    "category":"General Knowledge",
    "type":"multiple",
    "difficulty":"easy",
    "question":"When someone is cowardly, they are said to have what color belly?",
    "correct_answer":"Yellow",
    "incorrect_answers":["Green","Red","Blue","Yellow"],
    "answer_index": 3
  }

  /*{
    "id": 1,
    "category":"Science: Computers",
    "type":"multiple",
    "difficulty":"easy",
    "question":"What does CPU stand for?",
    "correct_answer":"Central Processing Unit",
    "incorrect_answers":["Central Process Unit","Computer Personal Unit","Central Processor Unit","Central Processing Unit"],
    "answer": 3
  },

  {
    "id": 2,
    "category":"Science: Computers",
    "type":"multiple",
    "difficulty":"easy",
    "question":"Which computer hardware device provides an interface for all other connected devices to communicate?",
    "correct_answer":"Motherboard",
    "incorrect_answers":["Central Processing Unit","Hard Disk Drive","Random Access Memory","Motherboard"],
    "answer": 3
  },

  {
    "id": 3,
    "category":"Science: Computers",
    "type":"multiple",
    "difficulty":"easy",
    "question":"In computing, what does LAN stand for?",
    "correct_answer":"Local Area Network",
    "incorrect_answers":["Long Antenna Node","Light Access Node","Land Address Navigation", "Local Area Network"],
    "answer": 3
  },

  {
    "id": 4,
    "category":"Science: Computers",
    "type":"multiple",
    "difficulty":"easy",
    "question":"In any programming language, what is the most common way to iterate through an array?",
    "correct_answer":"&#039;For&#039; loops",
    "incorrect_answers":["&#039;If&#039; Statements","&#039;Do-while&#039; loops","&#039;While&#039; loops","&#039;For&#039; loops"],
    "answer": 3
  },*/

];
